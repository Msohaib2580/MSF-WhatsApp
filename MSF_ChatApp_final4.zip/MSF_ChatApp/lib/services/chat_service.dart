import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ChatService {
  static final db = FirebaseFirestore.instance;
  static String get uid => FirebaseAuth.instance.currentUser!.uid;

  static Stream<QuerySnapshot<Map<String, dynamic>>> chats() =>
      db.collection('chats').where('participants', arrayContains: uid).snapshots();

  static Stream<QuerySnapshot<Map<String, dynamic>>> messages(String chatId) =>
      db.collection('chats').doc(chatId).collection('messages').orderBy('timestamp').snapshots();

  /// Email se dost dhoondta hai aur dono ke liye chat bana deta hai.
  static Future<Map<String, String>> startChatByEmail(String email) async {
    final e = email.trim().toLowerCase();
    final q = await db.collection('users').where('email', isEqualTo: e).limit(1).get();
    if (q.docs.isEmpty) {
      throw Exception('Is email ka koi user nahi mila. Dost pehle app mein account bana le.');
    }
    final other = q.docs.first;
    if (other.id == uid) throw Exception('Ye aap ki apni email hai.');
    final ids = [uid, other.id]..sort();
    final chatId = ids.join('_');
    final myEmail = FirebaseAuth.instance.currentUser!.email ?? '';
    final otherEmail = '${other.data()['email'] ?? e}';
    await db.collection('chats').doc(chatId).set({
      'participants': ids,
      'names': {uid: myEmail, other.id: otherEmail},
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    return {'id': chatId, 'title': otherEmail};
  }

  static Future<void> sendText(String chatId, String text) async {
    if (text.trim().isEmpty) return;
    final m = {'senderId': uid, 'type': 'text', 'text': text.trim(), 'timestamp': FieldValue.serverTimestamp()};
    await db.collection('chats').doc(chatId).collection('messages').add(m);
    await db.collection('chats').doc(chatId).set(
        {'lastMessage': text.trim(), 'updatedAt': FieldValue.serverTimestamp()}, SetOptions(merge: true));
  }
}
