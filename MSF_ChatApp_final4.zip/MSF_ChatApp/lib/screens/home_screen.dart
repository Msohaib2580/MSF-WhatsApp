import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/auth_service.dart';
import '../services/chat_service.dart';
import 'chat_screen.dart';
import 'admin_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Future<void> _newChat(BuildContext context) async {
    final ctrl = TextEditingController();
    final email = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New chat'),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.emailAddress,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'Dost ki email', border: OutlineInputBorder()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: const Text('Start')),
        ],
      ),
    );
    if (email == null || email.trim().isEmpty) return;
    try {
      final chat = await ChatService.startChatByEmail(email);
      if (context.mounted) {
        Navigator.push(context,
            MaterialPageRoute(builder: (_) => ChatScreen(chatId: chat['id']!, title: chat['title']!)));
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('$e'.replaceFirst('Exception: ', ''))));
      }
    }
  }

  String _titleOf(Map<String, dynamic> d) {
    final names = (d['names'] as Map?) ?? {};
    for (final e in names.entries) {
      if (e.key != ChatService.uid) return '${e.value}';
    }
    return 'Chat';
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('MSF ChatApp'), actions: [
          IconButton(
            icon: const Icon(Icons.admin_panel_settings),
            onPressed: () async {
              if (await AuthService.isAdmin() && context.mounted) {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminScreen()));
              }
            },
          ),
          IconButton(icon: const Icon(Icons.logout), onPressed: AuthService.signOut),
        ]),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _newChat(context),
          icon: const Icon(Icons.person_add),
          label: const Text('New chat'),
        ),
        body: Column(children: [
          Card(
            margin: const EdgeInsets.all(12),
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.person)),
              title: const Text('My Profile'),
              subtitle: Text(AuthService.currentUser?.email ?? AuthService.currentUser?.phoneNumber ?? ''),
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: ChatService.chats(),
              builder: (_, s) {
                if (s.hasError) {
                  return Center(child: Padding(padding: const EdgeInsets.all(16), child: Text('Error: ${s.error}')));
                }
                if (!s.hasData) return const Center(child: CircularProgressIndicator());
                final docs = s.data!.docs.toList();
                int ms(Map<String, dynamic> d) {
                  final t = d['updatedAt'];
                  return t is Timestamp ? t.millisecondsSinceEpoch : 9007199254740991;
                }
                docs.sort((a, b) => ms(b.data()).compareTo(ms(a.data())));
                if (docs.isEmpty) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text('Abhi koi chat nahi.\nNeeche "New chat" dabayein aur dost ki email dalein.',
                          textAlign: TextAlign.center),
                    ),
                  );
                }
                return ListView(
                  children: docs.map((doc) {
                    final d = doc.data();
                    final title = _titleOf(d);
                    return ListTile(
                      leading: CircleAvatar(child: Text(title.isEmpty ? '?' : title[0].toUpperCase())),
                      title: Text(title),
                      subtitle: Text('${d['lastMessage'] ?? ''}', maxLines: 1, overflow: TextOverflow.ellipsis),
                      onTap: () => Navigator.push(context,
                          MaterialPageRoute(builder: (_) => ChatScreen(chatId: doc.id, title: title))),
                    );
                  }).toList(),
                );
              },
            ),
          ),
        ]),
      );
}
