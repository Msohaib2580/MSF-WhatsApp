import 'package:flutter/material.dart';
import '../services/chat_service.dart';

class ChatScreen extends StatefulWidget {
  final String chatId;
  final String title;
  const ChatScreen({super.key, required this.chatId, this.title = 'Chat'});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final text = TextEditingController();

  void send() {
    final t = text.text;
    if (t.trim().isEmpty) return;
    text.clear();
    ChatService.sendText(widget.chatId, t).catchError((e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Send error: $e')));
    });
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: Column(children: [
          Expanded(
            child: StreamBuilder(
              stream: ChatService.messages(widget.chatId),
              builder: (_, s) {
                if (s.hasError) return Center(child: Text('Error: ${s.error}'));
                if (!s.hasData) return const Center(child: CircularProgressIndicator());
                final docs = s.data!.docs;
                return ListView.builder(
                  reverse: true,
                  itemCount: docs.length,
                  itemBuilder: (_, i) {
                    final d = docs[docs.length - 1 - i].data();
                    final mine = d['senderId'] == ChatService.uid;
                    return Align(
                      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        padding: const EdgeInsets.all(10),
                        constraints: const BoxConstraints(maxWidth: 280),
                        decoration: BoxDecoration(
                          color: mine ? Colors.blue.shade100 : Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Text('${d['text'] ?? ''}'),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          SafeArea(
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: text,
                  onSubmitted: (_) => send(),
                  decoration: const InputDecoration(hintText: 'Message', contentPadding: EdgeInsets.all(12)),
                ),
              ),
              IconButton(icon: const Icon(Icons.send), onPressed: send),
            ]),
          ),
        ]),
      );
}
