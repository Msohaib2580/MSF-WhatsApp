Android Firebase setup: put your real google-services.json in this folder after creating your Firebase Android app. Do not share private keys or service-account JSON in the app.
