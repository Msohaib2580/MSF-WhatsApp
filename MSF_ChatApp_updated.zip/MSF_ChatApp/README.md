# MSF ChatApp

Flutter/Firebase starter project containing:
- Phone Number + Firebase SMS OTP login
- Session/auto-login via Firebase Auth
- User profiles
- 1-to-1 chat foundation
- Group chat data model foundation
- Voice/video call UI/data foundation (WebRTC integration can be added)
- Photos, videos, voice messages and files storage foundation
- Firebase Cloud Messaging foundation
- Firestore + Storage security rules
- Admin Panel: dashboard, user records, user management, reports/complaints, suspension/disable/activate, basic settings

## Firebase setup
1. Create a Firebase Android project.
2. Add your Android app and place `google-services.json` in `android/app/`.
3. Enable Phone Authentication and Firestore/Storage/Cloud Messaging.
4. Run `flutterfire configure` or add the generated Firebase options according to your Flutter setup.
5. Create an admin document: `admins/{USER_UID}` with `{ "enabled": true }` after the admin user has logged in once.
6. Deploy `firebase/firestore.rules` and `firebase/storage.rules`.

## Important
This ZIP is a source starter and requires your own Firebase project/configuration for real SMS OTP, database, storage and notifications. Voice/video calls need a signaling + WebRTC service/configuration.
