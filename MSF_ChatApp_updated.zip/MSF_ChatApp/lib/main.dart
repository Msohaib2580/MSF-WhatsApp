import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/admin_screen.dart';
import 'services/auth_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try { await Firebase.initializeApp(); } catch (_) {}
  runApp(const MSFChatApp());
}

class MSFChatApp extends StatelessWidget {
  const MSFChatApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'MSF ChatApp',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
    home: StreamBuilder(
      stream: AuthService.authStateChanges,
      builder: (_, snap) => snap.hasData ? const HomeScreen() : const LoginScreen(),
    ),
    routes: {'/admin': (_) => const AdminScreen()},
  );
}
