import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ChatService {
  static final db = FirebaseFirestore.instance;
  static final uid = FirebaseAuth.instance.currentUser!.uid;
  static Stream<QuerySnapshot<Map<String,dynamic>>> chats() => db.collection('chats').where('participants', arrayContains: uid).orderBy('updatedAt', descending: true).snapshots();
  static Stream<QuerySnapshot<Map<String,dynamic>>> messages(String chatId) => db.collection('chats').doc(chatId).collection('messages').orderBy('timestamp').snapshots();
  static Future<void> sendText(String chatId, String text) async {
    if (text.trim().isEmpty) return;
    final m = {'senderId': uid, 'type': 'text', 'text': text.trim(), 'timestamp': FieldValue.serverTimestamp()};
    await db.collection('chats').doc(chatId).collection('messages').add(m);
    await db.collection('chats').doc(chatId).set({'lastMessage': text.trim(), 'updatedAt': FieldValue.serverTimestamp()}, SetOptions(merge: true));
  }
}
