import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import 'chat_screen.dart';
import 'admin_screen.dart';

class HomeScreen extends StatelessWidget { const HomeScreen({super.key});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('MSF ChatApp'),actions:[IconButton(icon:const Icon(Icons.admin_panel_settings),onPressed:() async {if(await AuthService.isAdmin() && context.mounted) Navigator.push(context,MaterialPageRoute(builder:(_)=>const AdminScreen()));}),IconButton(icon:const Icon(Icons.logout),onPressed:AuthService.signOut)]),body:ListView(padding:const EdgeInsets.all(16),children:[Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:const Text('My Profile'),subtitle:Text(AuthService.currentUser?.phoneNumber??''))),const SizedBox(height:8),const ListTile(leading:Icon(Icons.chat),title:Text('Chats'),subtitle:Text('Real-time Firebase chat')),const ListTile(leading:Icon(Icons.groups),title:Text('Groups'),subtitle:Text('Group chat and members')),const ListTile(leading:Icon(Icons.call),title:Text('Calls'),subtitle:Text('Voice / Video call structure')),const ListTile(leading:Icon(Icons.photo_library),title:Text('Media'),subtitle:Text('Photos, videos, voice and files')),FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ChatScreen(chatId:'demo_chat'))),icon:const Icon(Icons.forum),label:const Text('Open Demo Chat'))]));
}
