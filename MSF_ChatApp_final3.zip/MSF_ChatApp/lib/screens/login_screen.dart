import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/auth_service.dart';

class LoginScreen extends StatefulWidget { const LoginScreen({super.key}); @override State<LoginScreen> createState()=>_LoginScreenState(); }
class _LoginScreenState extends State<LoginScreen>{
  final email=TextEditingController(); final pass=TextEditingController(); bool loading=false;
  void msg(String t){ if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(t),duration:const Duration(seconds:8))); }
  Future<void> go(bool register) async {
    final e=email.text.trim(); final p=pass.text;
    if(e.isEmpty||p.length<6){ msg('Email likhein aur password kam az kam 6 characters ka rakhein'); return; }
    setState(()=>loading=true);
    try {
      final c = register ? await AuthService.registerEmail(e,p) : await AuthService.signInEmail(e,p);
      await AuthService.ensureUserProfile(c.user!);
    } on FirebaseAuthException catch(x){ msg('Error: ${x.code}'); }
    catch(x){ msg('$x'); }
    finally { if(mounted) setState(()=>loading=false); }
  }
  @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
    const Icon(Icons.chat_bubble_rounded,size:72,color:Colors.blue),
    const SizedBox(height:16),
    const Text('MSF ChatApp',style:TextStyle(fontSize:30,fontWeight:FontWeight.bold)),
    const SizedBox(height:28),
    TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'Email',border:OutlineInputBorder())),
    const SizedBox(height:12),
    TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'Password (min 6)',border:OutlineInputBorder())),
    const SizedBox(height:16),
    SizedBox(width:double.infinity,child:FilledButton(onPressed:loading?null:()=>go(false),child:Text(loading?'Please wait...':'Login'))),
    TextButton(onPressed:loading?null:()=>go(true),child:const Text('Create new account'))
  ]))));
}
