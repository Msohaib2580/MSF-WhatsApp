import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthService {
  static final _auth = FirebaseAuth.instance;
  static final _db = FirebaseFirestore.instance;
  static Stream<User?> get authStateChanges => _auth.authStateChanges();
  static User? get currentUser => _auth.currentUser;

  static Future<void> sendOtp({required String phone, required void Function(String) onCode, required void Function(String) onError}) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phone,
      verificationCompleted: (c) async {
        try { await _auth.signInWithCredential(c); } catch (e) { onError('$e'); }
      },
      verificationFailed: (e) => onError('${e.code}: ${e.message}'),
      codeSent: (id, _) => onCode(id),
      codeAutoRetrievalTimeout: (_) {},
    );
  }
  static Future<UserCredential> verifyOtp(String verificationId, String smsCode) =>
      _auth.signInWithCredential(PhoneAuthProvider.credential(verificationId: verificationId, smsCode: smsCode));
  static Future<void> ensureUserProfile(User user, {String? name}) async {
    final ref = _db.collection('users').doc(user.uid);
    final snap = await ref.get();
    if (!snap.exists) {
      await ref.set({'uid': user.uid, 'name': name ?? '', 'phone': user.phoneNumber ?? '', 'status': 'active', 'role': 'user', 'createdAt': FieldValue.serverTimestamp(), 'lastSeen': FieldValue.serverTimestamp()});
    }
  }
  static Future<bool> isAdmin() async {
    final u = currentUser; if (u == null) return false;
    final d = await _db.collection('admins').doc(u.uid).get();
    return d.exists && (d.data()?['enabled'] ?? true) == true;
  }
  static Future<void> signOut() => _auth.signOut();
}
